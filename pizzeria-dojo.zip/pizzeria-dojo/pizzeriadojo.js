function pizzaOven(tipoCorteza,tipoSalsa,quesos,salsas){
    var Pizza={};
    Pizza.tipoCorteza = tipoCorteza;
    Pizza.tipoSalsa = tipoSalsa;
    Pizza.quesos = quesos;
    Pizza.salsas = salsas;
    return  Pizza;
}
var estilo = pizzaOven("estilo Chicago","tradicional",["Mozzarella"],["pepperoni", "salchicha"]);
console.log(estilo)


function pizzaOven(tipoCorteza,tipoSalsa,quesos,salsas){
    var Pizza={};
    Pizza.tipoCorteza = tipoCorteza;
    Pizza.tipoSalsa = tipoSalsa;
    Pizza.quesos = quesos;
    Pizza.salsas = salsas;
    return  Pizza;
}
var estilo = pizzaOven("Lanzada a mano","marinara",["Mozzarella", "feta"],["champiñones", "aceitunas","cebollas"]);
console.log(estilo)


function pizzaOven(Masa,Salsa,quesos,salsas){
    var Pizza={};
    Pizza.Masa = Masa;
    Pizza.Salsa = Salsa;
    Pizza.quesos = quesos;
    return  Pizza;
}
var estilo = pizzaOven("Delgada","Arrabiata",["Parmesano", "Feta","Holandés"]);
console.log(estilo)


function pizzaOven(Masa,Salsa,quesos,salsas){
    var Pizza={};
    Pizza.Masa = Masa;
    Pizza.Salsa = Salsa;
    Pizza.quesos = quesos;
    return  Pizza;
}
var estilo = pizzaOven("Gruesa",["Amatriciana","Puttanesca","Boloñesa"],["Gauda", "Cheddar"]);
console.log(estilo)